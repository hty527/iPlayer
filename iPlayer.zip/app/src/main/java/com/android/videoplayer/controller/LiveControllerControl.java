package com.android.videoplayer.controller;

import android.content.Context;
import com.android.iplayer.base.BaseController;

/**
 * created by hty
 * 2022/8/29
 * Desc:直播场景控制器
 */
public class LiveControllerControl extends BaseController {

    public LiveControllerControl(Context context) {
        super(context);
    }

    @Override
    public int getLayoutId() {
        return 0;
    }

    @Override
    public void initViews() {

    }
}