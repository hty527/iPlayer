package com.android.videoplayer.base.adapter.interfaces;

import android.view.View;

/**
 * created by hty
 * 2022/7/1
 * Desc:
 */
public interface OnItemChildClickListener {
    void onItemClick(View view, int position, long itemId);
}