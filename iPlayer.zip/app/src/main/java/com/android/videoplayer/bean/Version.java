package com.android.videoplayer.bean;

/**
 * created by hty
 * 2022/8/1
 * Desc:预更新信息
 */
public class Version {

    private String code;
    private String descript;
    private String time;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescript() {
        return descript;
    }

    public void setDescript(String descript) {
        this.descript = descript;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}